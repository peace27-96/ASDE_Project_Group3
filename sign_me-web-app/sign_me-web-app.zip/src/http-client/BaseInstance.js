import axios from 'axios'

export default axios.create({
    //baseURL:"http://192.168.43.219:8080/signme/"
    baseURL:"http://localhost:8080/signme/"
})      